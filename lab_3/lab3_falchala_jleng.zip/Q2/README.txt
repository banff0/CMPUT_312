For Q2, server.py is meant to be running on the machine connected to the 
ev3dev, and client.py is meant to be running on the ev3dev. They are supposed
to be running simultaneously, preferably starting with server.py.